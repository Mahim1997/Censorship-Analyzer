class HTTPSDescription:
