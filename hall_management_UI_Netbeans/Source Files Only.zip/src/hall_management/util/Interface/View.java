/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hall_management.util.Interface;

/**
 *
 * @author suban
 */
public interface View {
    String Student = "VW_STUDENT";
    String Teacher = "VW_TEACHER";
    String Hall = "VW_HALL";
    String Staff = "VW_STAFF";    
    String StudentGuestList = "VW_STUDENT_GUEST_LIST";
}
