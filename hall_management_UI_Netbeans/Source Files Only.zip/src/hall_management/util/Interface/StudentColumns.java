/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hall_management.util.Interface;

/**
 *
 * @author esfs
 */
public interface StudentColumns {
    public static int idIndex = 0;
    public static int nameIndex = 1;
    public static int deptIndex = 2;
    public static int addressIndex = 3;
    public static int birthDateIndex = 4;
    public static int religionIndex = 5;
    public static int fatherIndex = 6;
    public static int motherIndex = 7;
    public static int genderIndex = 8;
    public static int bloodGrpIndex = 9;
    public static int contactNumIndex = 10;
    
}
