package hall_management.util.Interface;

 
public interface Type {
    public static final int type_Student = 0;
    public static final int type_Teacher = 1;
    public static final int type_Staff = 2;
    public static final int type_Admin = 3;
    public static final int type_Guest = 4;
}
