/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hall_management.util.Interface;

/**
 *
 * @author suban
 */
public interface Sounds {
    String CONFIRM = "src\\hall_management\\ui\\sounds\\Confirm.mp3";
    String ERROR = "src\\hall_management\\ui\\sounds\\Error.mp3";

}
