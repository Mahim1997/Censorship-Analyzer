package hall_management.db.queries.adminQueries;

import hall_management.db.connection.MyConnection;
import java.sql.Connection;

public class AdminQueries {
    public static final MyConnection connectionObject = new MyConnection();
    public static final Connection con = connectionObject.getConnection();
    
}
