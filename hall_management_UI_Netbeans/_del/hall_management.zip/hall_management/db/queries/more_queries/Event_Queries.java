package hall_management.db.queries.more_queries;

import hall_management.db.connection.MyConnection;
import hall_management.db.queries.Query;
import hall_management.ui.startPage.Main;
import hall_management.ui.teacher.events.Events;
import hall_management.ui.teacher.upcomingEvents.Teams;
import hall_management.util.Interface.Table;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Event_Queries {

    public static final MyConnection connectionObject = new MyConnection();
    public static final Connection con = connectionObject.getConnection();

    public static String quote(String s) {
        String[]arr = s.split("'");
        if(arr.length <= 1)
            return " '" + s + "' ";
        else
            return s;
    }

    public static String getNextEventID() throws Exception {
        String query = "SELECT MAX(EVENT_ID) + 1 FROM " + Table.Event;
        Statement st = con.createStatement();
        st.execute(query);
        ResultSet rs = st.getResultSet();
        String id = "1";
        if (rs.next()) {
            if (rs.getString(1) != null) {
                id = rs.getString(1);
            }
        }
        return id;
    }

    public static List<Events> getListOfEventsSupervisedBy(String teacherID, String status) throws SQLException {
        List<Events> list = new ArrayList<>();
        String query = "SELECT * FROM " + Table.Event + " WHERE UPPER(EVENT_TYPE) = " + quote(status) + " AND EVENT_SUPERVISOR_ID = " + teacherID;
        Statement st = con.createStatement();
        System.out.println("=->> Inside Event_Queries.getListOfEventsSupervisedBy.. query is \n" + query);
        st.execute(query);
        ResultSet rs = st.getResultSet();
        Events event = new Events();
        while (rs.next()) {
            list.add(new Events(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
                    rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8),
                    rs.getString(9), rs.getString(10)));
        }

        return list;
    }

    public static String getFieldOfEvent(String tableName, String fieldName, String eventOrTeamIDQualifier, String idValue) throws Exception {
        String query = "SELECT " + fieldName + " FROM " + tableName + " WHERE "
                + eventOrTeamIDQualifier + " = " + idValue;
        Statement st = con.createStatement();
        System.out.println("=->> Inside Event_Queries.getFieldOfEvent.. query is \n" + query);
        st.execute(query);
        ResultSet rs = st.getResultSet();
        if (rs.next()) {
            return rs.getString(1);
        }
        return null;
    }

    /*
    String team_id;
    String team_name;
    String team_year;
    String team_sport;
    String team_type;
    String hallID;
    String hallName;
    String captainStudentID;
     */
    public static List<Teams> getListOfTeamsForEventID(String event_id, String status) throws Exception {
        List<Teams> list = new ArrayList<>();
//        String query = "SELECT * FROM " + Table.Team + " WHERE UPPER(EVENT_TYPE) = " + quote(status) + " AND EVENT_SUPERVISOR_ID = " + teacherID;

        String query = "SELECT t.TEAM_ID , t.TEAM_NAME, t.TEAM_YEAR, t.TEAM_SPORT, t.TEAM_TYPE, t.HALL_ID, \n"
                + "(SELECT TABLE_HALL.HALL_NAME FROM TABLE_HALL WHERE TABLE_HALL.HALL_ID = t.HALL_ID), CAPTAIN_STUDENT_ID\n"
                + "FROM TABLE_TEAM t ,TABLE_EVENT e\n"
                + "WHERE (UPPER(t.TEAM_SPORT) = UPPER(e.EVENT_SPORT))"
                + " AND (UPPER(t.TEAM_TYPE) = UPPER(e.EVENT_STATUS)) "
                + " AND (t.TEAM_YEAR = e.EVENT_YEAR)\n"
                + " AND e.EVENT_ID = " + event_id
                + " AND e.EVENT_STATUS = " + quote(status) ;
        Statement st = con.createStatement();
        System.out.println("=->> Inside Event_Queries.getListOfTeamsForEventID.. query is \n" + query);
        st.execute(query);
        ResultSet rs = st.getResultSet();
        Teams team = new Teams();

        while (rs.next()) {
            team = new Teams(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8));
            list.add(team);
        }

        return list;
    }

}
