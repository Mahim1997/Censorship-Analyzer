/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hall_management.ui.admin;

import com.jfoenix.controls.JFXTextField;
import hall_management.ui.pushNotification.Notification;
import hall_management.util.Interface.Controller;
import hall_management.util.Interface.Scenes;
import hall_management.util.SceneLoader;
import java.net.URL;
import java.util.Calendar;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;

/**
 * FXML Controller class
 *
 * @author suban
 */
public class modifyHallController implements Initializable, Controller {

    @FXML
    private JFXTextField textLabel_hallID;
    @FXML
    private JFXTextField textLabel_provostID;
    @FXML
    private JFXTextField start_day;
    @FXML
    private JFXTextField start_month;
    @FXML
    private JFXTextField start_year;

    String hallID, provostID, start_date;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void submitInfoToUpdate(ActionEvent event) {
        
        hallID = textLabel_hallID.getText();
        provostID = textLabel_provostID.getText();
        
        if(hallID.isEmpty() || provostID.isEmpty() || start_day.getText().isEmpty() || start_month.getText().isEmpty() || start_year.getText().isEmpty())
        {
            Notification.push("FAILED", "Fill up all fields", Notification.FAILURE, Pos.CENTER);
            return;            
        }
        
        int day, mon, year;
        try {
            day = Integer.parseInt(start_day.getText());
            mon = Integer.parseInt(start_month.getText());
            year = Integer.parseInt(start_year.getText());
        } catch (NumberFormatException e) {
            Notification.push("FAILED", "Invalid Date Format", Notification.FAILURE, Pos.CENTER);
            return;             
        }
        
        if(day>31 || day<1 || mon>12 || mon<1){
            Notification.push("FAILED", "Invalid Date Format", Notification.FAILURE, Pos.CENTER);
            return;                         
        }
        
        start_date = ""+day+"/"+mon+"/"+year;
        
        // update query
    }

    @FXML
    private void goBack(ActionEvent event) {
        SceneLoader.closeScene(SceneLoader.CurrentScene());
        SceneLoader.loadPreviousScene(Scenes.admin_ui, this);
    }

}
