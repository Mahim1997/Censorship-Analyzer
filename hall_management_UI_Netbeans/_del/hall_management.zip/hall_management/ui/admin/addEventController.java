/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hall_management.ui.admin;

import com.jfoenix.controls.JFXTextField;
import hall_management.ui.pushNotification.Notification;
import hall_management.util.Interface.Controller;
import hall_management.util.Interface.Scenes;
import hall_management.util.SceneLoader;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;

/**
 * FXML Controller class
 *
 * @author suban
 */
public class addEventController implements Initializable,Controller {

    @FXML
    private JFXTextField textLabel_fullName;
    @FXML
    private JFXTextField textLabel_year;
    @FXML
    private JFXTextField textLabel_sport;
    @FXML
    private JFXTextField textLabel_hallName;
    @FXML
    private JFXTextField textLabel_superVisID;
    @FXML
    private JFXTextField textLabel_status;

    String eventName,year,hallName,superVisorID,sport,status;
    
    boolean checkValid()
    {
        if(eventName.isEmpty() || year.isEmpty() || superVisorID.isEmpty() || sport.isEmpty() || status.isEmpty())
            return false;
        try {
            Integer.parseInt(superVisorID);
        } catch (Exception e) {
            return false;
        }
       return true;
    }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    boolean isHallNameValid()
    {
        if(hallName.isEmpty()) return true; // not a hall event
        return false;
    }
    
    @FXML
    private void submitInfoToAdd(ActionEvent event) {
        eventName = textLabel_fullName.getText();
        year = textLabel_year.getText();
        sport = textLabel_sport.getText();
        hallName = textLabel_hallName.getText();
        superVisorID = textLabel_superVisID.getText();
        status = textLabel_status.getText();
        String type = hallName.isEmpty() ? "GLOBAL" : "LOCAL";
        
        if(!checkValid()){
            Notification.push("Error", "Provide all fields", Notification.FAILURE, Pos.CENTER);
        }
        if(!isHallNameValid()){
            Notification.push("Error", "Hall does not Exists", Notification.FAILURE, Pos.CENTER);            
        }
    }

    @FXML
    private void clear(ActionEvent event) {
        textLabel_fullName.setText("");
        textLabel_year.setText("");
        textLabel_sport.setText("");
        textLabel_hallName.setText("");
        textLabel_superVisID.setText("");
        textLabel_status.setText("");
    }

    @FXML
    private void goBack(ActionEvent event) {
        SceneLoader.closeScene(SceneLoader.CurrentScene());
        SceneLoader.loadPreviousScene(Scenes.admin_ui, this);
    }
    
}
