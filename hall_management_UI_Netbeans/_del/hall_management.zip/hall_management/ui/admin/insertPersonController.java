/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hall_management.ui.admin;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import hall_management.util.Interface.Controller;
import hall_management.util.Interface.Scenes;
import hall_management.util.SceneLoader;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.MenuButton;
import javafx.scene.control.SplitMenuButton;

/**
 * FXML Controller class
 *
 * @author suban
 */
public class insertPersonController implements Initializable,Controller {

    @FXML
    private JFXTextField textField_studentID;
    @FXML
    private JFXButton button_refresh;
    @FXML
    private JFXTextField textLabel_teacherID;
    @FXML
    private JFXButton button_save1;
    @FXML
    private JFXButton button_refresh1;
    @FXML
    private JFXTextField textLabel_staffID;
    @FXML
    private JFXTextField textField_dept_std;
    @FXML
    private JFXTextField textField_addr_std;
    @FXML
    private JFXTextField textField_fatherName_std;
    @FXML
    private JFXTextField textField_motherName_std;
    @FXML
    private JFXTextField textField_contactNo_std;
    @FXML
    private JFXTextField textField_dateOfBirth_day_std;
    @FXML
    private JFXTextField textField_dateOfBirth_month_std;
    @FXML
    private JFXTextField textField_dateOfBirth_year_std;
    @FXML
    private MenuButton textField_gender_std;
    @FXML
    private SplitMenuButton textField_religion_std;
    @FXML
    private SplitMenuButton textField_bldgrp_std;
    @FXML
    private JFXTextField text_firstName_std;
    @FXML
    private JFXTextField text_lastName_std;
    @FXML
    private JFXPasswordField textField_pass_std;
    @FXML
    private JFXTextField textLabel_departmentID_teacher;
    @FXML
    private JFXTextField textLabel_designation_teacher;
    @FXML
    private JFXTextField textField_contactNo_teacher;
    @FXML
    private MenuButton text_gender_teacher;
    @FXML
    private JFXTextField text_firstName_teacher;
    @FXML
    private JFXTextField text_lastName_teacher;
    @FXML
    private JFXPasswordField textField_pass_teacher;
    @FXML
    private JFXTextField textLabel_contactNo_stf;
    @FXML
    private JFXTextField textLabel_jobType_stf;
    @FXML
    private JFXTextField text_firstName_stf;
    @FXML
    private JFXTextField text_lastName_stf;
    @FXML
    private JFXPasswordField text_pass_stf;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void submitStudent(ActionEvent event) {
    }

    @FXML
    private void clearStudent(ActionEvent event) {
    }

    @FXML
    private void submitTeacher(ActionEvent event) {
    }

    @FXML
    private void clearTeacher(ActionEvent event) {
    }

    @FXML
    private void addStaff(ActionEvent event) {
    }

    @FXML
    private void clearStaff(ActionEvent event) {
    }

    @FXML
    private void goBack(ActionEvent event) {
        SceneLoader.closeScene(SceneLoader.CurrentScene());
        SceneLoader.loadPreviousScene(Scenes.admin_ui, this);
    }
    
}
