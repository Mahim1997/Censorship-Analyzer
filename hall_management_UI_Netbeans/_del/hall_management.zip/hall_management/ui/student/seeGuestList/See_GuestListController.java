package hall_management.ui.student.seeGuestList;

import com.jfoenix.controls.JFXButton;
import hall_management.db.queries.Query;
import hall_management.ui.startPage.Main;
import hall_management.util.Interface.Controller;
import hall_management.util.Interface.Scenes;
import hall_management.util.SceneLoader;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;

public class See_GuestListController implements Initializable, Controller {

    @FXML
    private Text text_UporerPart;
    @FXML
    private JFXButton button_Back;

    private String uporerPartErText;
    @FXML
    private TableView tableview;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        try {
            runInitialQuery();
            runGuestPartQuery();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void goBack(ActionEvent event) {
//        SceneLoader.loadScene(Scenes.student_ui, this);
        SceneLoader.closeScene(SceneLoader.CurrentScene());
        SceneLoader.loadPreviousScene(Scenes.student_ui, this);
    }

    private void runGuestPartQuery() throws Exception {
        List<AllowedGuest> allowedGuestList = Query.getAllowedGuests(Main.studentID);

        List<AllowedGuest_WithButton> allowedGuestList_withButton = new ArrayList<>();

        AllowedGuest guest = new AllowedGuest();
        AllowedGuest_WithButton withButton = new AllowedGuest_WithButton();

        for (int i = 0; i < allowedGuestList.size(); i++) {
            guest = allowedGuestList.get(i);
            withButton = new AllowedGuest_WithButton(guest.getNID(), Main.studentID, guest.getRelationWithStudent(), guest.getGuestFullName(), guest.getGuestAddress(), guest.getGuestContactNumber());
            allowedGuestList_withButton.add(withButton);
        }

        initialiseTableViewUsing(allowedGuestList_withButton);

    }

    private void runInitialQuery() throws Exception {
        String[] arr = Query.findHallIDAndNameOfStudent(Main.studentID);
        String hall_id = arr[0];
        String hall_name = arr[1];
        uporerPartErText = "Student ID : " + Main.studentID + " , Hall Name : " + hall_name;
        System.out.println("UPORER TEXT IS " + uporerPartErText);
        text_UporerPart.setText(uporerPartErText);
    }

    /*
        public String NID ;
    public String studentId;
    public String relationWithStudent;
    public String guestFullName;
    public String guestAddress;
    public String guestContactNumber;
     */
    private void initialiseTableViewUsing(List<AllowedGuest_WithButton> list) {

        TableColumn col_nid = new TableColumn("NID");
        TableColumn col_fullName = new TableColumn("Full Name");
        TableColumn col_relation = new TableColumn("Relation With Student");
        TableColumn col_add = new TableColumn("Address");
        TableColumn col_contactNo = new TableColumn("Contact No");

        TableColumn btnCol = new TableColumn("See Guest Log");

        tableview.getColumns().addAll(col_nid, col_fullName, col_relation, col_add, col_contactNo, btnCol);
//        ObservableList<Application> data = getObservableArrayList(Main.studentID);
        

        ObservableList<AllowedGuest_WithButton> data = FXCollections.observableArrayList(list);

        col_nid.setCellValueFactory(
                new PropertyValueFactory<AllowedGuest_WithButton, String>("NID")
        );
        col_fullName.setCellValueFactory(
                new PropertyValueFactory<>("guestFullName")
        );
        col_relation.setCellValueFactory(
                new PropertyValueFactory<>("relationWithStudent")
        );
        col_add.setCellValueFactory(
                new PropertyValueFactory<>("applicationStatus")
        );
        col_contactNo.setCellValueFactory(
                new PropertyValueFactory<>("guestContactNumber")
        );
 
        btnCol.setCellValueFactory(
                new PropertyValueFactory<>("button")
        );
 
        tableview.setItems(data);
    }

}
