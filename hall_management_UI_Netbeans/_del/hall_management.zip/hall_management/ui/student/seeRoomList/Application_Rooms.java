package hall_management.ui.student.seeRoomList;


public class Application_Rooms {
    private String room_no;

    public Application_Rooms(String room_no) {
        this.room_no = room_no;
    }

    public Application_Rooms() {
    }

    public String getRoom_no() {
        return room_no;
    }

    public void setRoom_no(String room_no) {
        this.room_no = room_no;
    }
    
}
