/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hall_management.util.Interface;

/**
 *
 * @author suban
 */
public interface Table {
    String Student = "TABLE_STUDENT";
    String Teacher = "TABLE_TEACHER";
    String Hall = "TABLE_HALL";
    String Staff = "TABLE_STAFF";
    String Guest = "TABLE_GUEST";
    String Guest_Pass = "TABLE_GUEST_PASS";
    String Allowed_Guest = "TABLE_ALLOWED_GUEST";
    String Hall_Head_History = "TABLE_HALL_HEAD_HISTORY";
 
    String Application = "TABLE_APPLICATION";
    String Application_RoomList = "TABLE_APPLICATION_ROOM_LIST";
    
    String Room = "TABLE_ROOM";
    
    
    String Staff_WorksAtHall = "TABLE_STAFF_WORKSAT_HALL";
    
    
    String Team = "TABLE_TEAM";
    String Student_Forms_Team = "TABLE_STUDENT_FORMS_TEAM";
    String Event = "TABLE_EVENT";
    String Team_Event_History = "TABLE_TEAM_EVENT_HISTORY";
}
